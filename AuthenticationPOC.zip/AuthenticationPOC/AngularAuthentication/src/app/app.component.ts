import { Component, Injectable, OnInit } from '@angular/core';
import { Logger, CryptoUtils } from 'msal';
import {NestedTreeControl} from '@angular/cdk/tree';
import {MatTreeNestedDataSource} from '@angular/material/tree';
import { Adal8HTTPService, Adal8Service } from 'adal-angular8';
import { environment } from "../../src/environments/environment";



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
@Injectable()
export class AppComponent implements OnInit {
  title = 'Authentication';
  isIframe = false;
  loggedIn = false;
  username: string = null;
  userEmail;
  treeControl = new NestedTreeControl<FoodNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<FoodNode>();

  // config =  {
  //   tenant: 'lntts.onmicrosoft.com',
  //   clientId: 'd926a7c6-d4bb-412e-b391-4d1910cc7d9f',
  //   redirectUri : 'http://localhost:4200',
  //   endpoints: {
  //     'http://localhost:4200/': 'the id'
    
  //   }
  // }

  
  config =  {
    tenant: environment.tenant,
    clientId: environment.clientId,
    redirectUri : environment.redirectUri,
    endpoints:environment.endpoints 
  }

  
  constructor( private adal8HttpService: Adal8HTTPService,
    private adal8Service: Adal8Service) { 
    this.dataSource.data = TREE_DATA;
    this.adal8Service.init(this.config);
        this.adal8Service.handleWindowCallback();
  }
  hasChild = (_: number, node: FoodNode) => !!node.children && node.children.length > 0;
  ngOnInit() {
    this.isIframe = window !== window.parent && !window.opener;
    console.log(this.adal8Service.userInfo);
    if(this.adal8Service.userInfo.authenticated){
      this.loggedIn = true;
    }
    else
    this.loggedIn = false;
  }

  userFunction(){
    console.log(this.adal8Service.userInfo['profile']['given_name']);
    this.username = this.adal8Service.userInfo['profile']['given_name'];
    this.userEmail = this.adal8Service.userInfo['userName'];

  }

  login() {
    this.adal8Service.login();
  }

  logout() {
    this.adal8Service.logOut();
  }

 
}

interface FoodNode {
  name: string;
  children?: FoodNode[];
}

const TREE_DATA: FoodNode[] = [
  {
    name: 'OSSwellPackers',
    children: [
      {name: 'SPOS'},
      {name: 'SPOSL'},
      {name: 'SPLSR'},
    ]
  }, 
];
