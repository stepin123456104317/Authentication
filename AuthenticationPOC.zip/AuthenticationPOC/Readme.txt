For installing and running the App

terminal commands:
npm install
ng serve --port 5000



To change the values for tenant, redirectUri and client ID please navigate to:

src/environments/environments.ts  OR  src/environments/environments.prod.ts



